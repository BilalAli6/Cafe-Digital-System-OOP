#ifndef USER_H
#define USER_H

class User {
public:
    virtual void login() = 0;
    virtual void registerUser() = 0;
    virtual void forgotPassword() = 0;
    void removePerson1(); 
    void removePerson(); 
};

#endif // USER_H

