#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "User.h"

class Employee : public User {
public:
    virtual void login() override;
    virtual void registerUser() override;
    virtual void forgotPassword() override;
    void employee();
    void etakeorder();
    void esearchitem();
    void egeneratetransaction();
    void eseeonlineorder();
};

#endif // EMPLOYEE_H

