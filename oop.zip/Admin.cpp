#include "Admin.h"
#include <iostream>
#include <fstream>
#include <cstring>
#include <ctime>
#include <limits>

using namespace std;

// Implementing member functions of Admin class
void Admin::login() {
ifstream fs("adm.txt", ios::in);
    if (!fs) {
        cout << "\nFile Not Found\n\nCheck File Name";
    } else {
        int role;
        cout << "\nFile Foundd\n";

        char password[20];
        char id[20];
        char pass[20];
        char user[20];
        int count = 0;

        cout << "\t\t\nPlease Enter UserName and Pin :\n";
        cout << "\t\tUserName\n";
        cin >> user;
        cout << "\t\t\nPin\n";
        cin >> password;

        ifstream input("adm.txt");
        while (input >> id >> pass) {
            if (strcmp(id, user) == 0 && strcmp(pass, password) == 0) {
                count = 1;
            }
        }
        input.close();

        if (count == 1) {
            cout << user << "\n\tYou are logged in successfully\n\t";
        } else {
            cout << "\t\t\nLogin Error\nPlease Try Again\n\t";
            login(); // Recursively call login if login fails
        }
    }
}

void Admin::registerUser() {
    char ruser[20];
    char rpassword[20];

    cout << "\t\t\t\nEnter the user name :\t\t\n";
    cin >> ruser;

    cout << "\t\t\t\nEnter the Pin :\t\t\n";
    cin >> rpassword;

    ofstream f1("records.txt", ios::out | ios::app);

    f1 << ruser << " " << rpassword << endl;

    cout << "\t\t\nYour Registration has been done successfully\t\t\n";

}

void Admin::forgotPassword() {
    int option;
    cout << "\t\t\t\nYou forgot the password.\nNo worries:)\t\t\n";
    cout << "\nPress 1 to search your id by user name :\n";
    cout << "\nPress 2 to go back to the main menu :\n\n";
    cout << "\t\tEnter your choice :\t\t";
    cin >> option;

    switch (option) {
        case 1: {
            int count = 0;

            char suser[20];
            char sid[20];
            char spass[20];

            cout << "\t\t\nEnter username which you remember :\t\t\n";
            cin >> suser;

            ifstream f2("adm.txt");

            while (f2 >> sid >> spass) {
                if (strcmp(sid, suser) == 0) {
                    count = 1;
                    break;
                }
            }

            f2.close();

            if (count == 1) {
                cout << "\t\t\nCongrats Your account has been found\t\t\n";
                cout << "\t\t\nYour Pin is :" << spass << endl;
            } else {
                cout << "\t\t\nYour account has not been found\t\t\n";
            }
            break;
        }
        case 2: {
            // Return to main menu
            break;
        }
        default: {
            cout << "\t\t\nWrong Choice Please Try Again\t\t\n";
            forgotPassword(); // Recursively call forgotPassword if choice is invalid
            break;
        }
    }

}

void Admin::admin() 
{
    cout << "\n\t\t\t\t==============================================\n";
    cout << "\t\t\t\t       WELCOME TO THE ADMIN CDS SYSTEM       \n";
    cout << "\t\t\t\t==============================================\n\n";
}

void Admin::aseestock() {
    int c;                                  // is funtion me admin sara stock dkh skta ha
    char hdr[50], iT_Name[5][35];
    double Price[5];
    int No_Items[5];
    int i = 0;

    fstream fs("stock.txt", ios::in);

    if (!fs)//check if file is not available to read
    {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    } else//file is available for reading now loading data in arrays appropriately
    {
        cout << "\nFile Found Congrats";
        fs.getline(hdr, 35, '\n'); //reading first line of file
        //reading remianing records of file in arrays appropriately
        while (fs.getline(iT_Name[i], 50, ' '), fs >> Price[i] >> No_Items[i]) {
            fs.ignore();
            i++;
        }
    }

    fs.close();
    //now printing data from arrays on screen

    cout << "\nData read from file in arrays ::: \n";
    cout << "\n" << hdr << endl;
    for (int k = 0; k < i; k++) {
        cout << iT_Name[k] << "    |    " << Price[k] << "    |    " << No_Items[k] << endl;
    }


}

void Admin::aseeloweritem() {
   char hdr[50], iT_Name[5][35];
    double Price[5];
    int No_Items[5];
    int i = 0;

    fstream fs("stock.txt", ios::in);

    if (!fs) // check if file is not available to read
    {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    } else // file is available for reading, now loading data in arrays appropriately
    {
        cout << "\nFile Found Congrats";
        fs.getline(hdr, 50, '\n'); // reading first line of the file
        // reading remaining records of the file in arrays appropriately
        while (fs.getline(iT_Name[i], 35, ' '), fs >> Price[i] >> No_Items[i]) {
            fs.ignore(); 
            i++;
        }
    }

    fs.close();
    // now printing data from arrays on screen

    cout << "\nData read from file in arrays ::: \n";
    cout << "\n" << hdr << endl;
    for (int k = 0; k < i; k++) {
        cout << iT_Name[k] << "    |    " << Price[k] << "    |    " << No_Items[k] << endl;

        // Check if No_Items is less than 10 and generate a message
        if (No_Items[k] < 10) {
            cout << "\nWarning: The quantity of " << iT_Name[k] << " is below 10!\n";
        }
    }

}

void Admin::aseelowerorderitem() {
     ifstream fs("loworders.txt");                         // is me admin wo item dkh skta ha jo order tu hue lekin quantity low hone ki wajah se dispatch nahi ho ske aur mazrat ho gye

    if (!fs) {
        cout << "File not found or empty.\n";
    } else {

        char lines[100][200];  // Adjust the second dimension based on the expected line length

        int lineCount = 0;

        while (fs.getline(lines[lineCount], sizeof(lines[lineCount]))) {
            lineCount++;
        }

        fs.close();

        // Display the content from arrays
        cout << "Low Quantity Orders:\n";
        cout << "------------------------------------\n";
        for (int i = 0; i < lineCount; ++i) {
            cout << lines[i] << endl;
        }
    }
}

void Admin::asearchitem() {
   char hdr[50], Name[5][20];
    double Price[5];
    int No_Items[5];
    int i = 0;

    fstream fs("stock.txt", ios::in);

    if (!fs)//check if file is not available to read
    {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    } else//file is available for reading now loading data in arrays appropriately
    {
        cout << "\nFile Found Congrats";
        fs.getline(hdr, 50, '\n');//reading first line of file
        //reading remianing records of file in arrays appropriately
        while (fs.getline(Name[i], 20, ' '), fs >> Price[i] >> No_Items[i]) {
            fs.ignore();
            i++;
        }
    }

    fs.close();
    //now printing data from arrays on screen

    cout << "\nData read from file in arrays ::: \n";
    cout << "\n" << hdr << endl;
    for (int k = 0; k < i; k++) {
        cout << Name[k] << "    |    " << Price[k] << "    |    " << No_Items[k] << endl;
    }

    char search[] = "Chowmin";///you can take input here as well
    int p = 0;


    while (1)//this loop is used to find location in array.
    {
        if (strcmp(Name[p], search) == 0) {
            break;
        } else p++;
    }
    cout << "\n\nFound at location = " << p << "\n\n";

}
void Admin::aaddemployee() {
    int b;
    
    cout << "\n\t\tPress 1 to see, remove or add in student's list\n";
    cout << "\n\t\tPress 2 to see, remove or add in employee's list\n";
    cin >> b;
    
    switch (b) {
        case 1: {
            int a;

            cout << "\n\t\tPress 1 if you want to see list of students\n";
            cout << "\n\t\tPress 2 if you want to remove any students\n";
            cout << "\n\t\tPress 3 if you want to add any students\n";
            cin >> a;

            switch (a) {
                case 1: {
char hdr[20], Name[10][100];
            int Pass[10];

            int i = 0;

            fstream fs("student.txt", ios::in);

            if (!fs)//check if file is not available to read
            {
                cout << "\nFile not found";
                cout << "\nCheck file name";
            } else//file is available for reading now loading data in arrays appropriately
            {
                cout << "\nFile Found Congrats";
                fs.getline(hdr, 20, '\n');//reading first line of file
                //reading remianing records of file in arrays appropriately
                while (fs.getline(Name[i], 100, ' '), fs >> Pass[i]) {
                    fs.ignore();
                    i++;
                }
            }

            fs.close();
            //now printing data from arrays on screen

            cout << "\nData read from file in arrays ::: \n";
            cout << "\n" << hdr << endl;
            for (int k = 0; k < i; k++) {
                cout << Name[k] << " " << Pass[k] << " " << endl;
            }

            break;
                }
                case 2: {
               
                removePerson1();
            break;

                }
                case 3: {
char ruser[20];
            char rpassword[20];

            cout << "\t\t\t\nEnter the user name :\t\t\n";
            cin >> ruser;

            cout << "\t\t\t\nEnter the Pin :\t\t\n";
            cin >> rpassword;

            ofstream f1("student.txt", ios::out | ios::app);

            f1 << ruser << " " << rpassword << endl;

            cout << "\t\t\nYour Registration has been done successfully\t\t\n";
            break;

                }
                default: {
                    cout << "\t\t\nInvalid input. Please enter a valid integer.\n";
                    break;
                }
            }
            break;
        }
        case 2: {
            int a;

            cout << "\n\t\tPress 1 if you want to see list of employees\n";
            cout << "\n\t\tPress 2 if you want to remove any employees\n";
            cout << "\n\t\tPress 3 if you want to add any employees\n";
            cin >> a;

            switch (a) {
                case 1: {
char hdr[20], Name[10][100];
            int Pass[10];

            int i = 0;

            fstream fs("records.txt", ios::in);

            if (!fs)//check if file is not available to read
            {
                cout << "\nFile not found";
                cout << "\nCheck file name";
            } else//file is available for reading now loading data in arrays appropriately
            {
                cout << "\nFile Found Congrats";
                fs.getline(hdr, 20, '\n');//reading first line of file
                //reading remianing records of file in arrays appropriately
                while (fs.getline(Name[i], 100, ' '), fs >> Pass[i]) {
                    fs.ignore();
                    i++;
                }
            }

            fs.close();
            //now printing data from arrays on screen

            cout << "\nData read from file in arrays ::: \n";
            cout << "\n" << hdr << endl;
            for (int k = 0; k < i; k++) {
                cout << Name[k] << " " << Pass[k] << " " << endl;
            }

            break;

                }
    
     case 2: {
                          removePerson();
                          break;

                }
                case 3: {
char ruser[20];
            char rpassword[20];

            cout << "\t\t\t\nEnter the user name :\t\t\n";
            cin >> ruser;

            cout << "\t\t\t\nEnter the Pin :\t\t\n";
            cin >> rpassword;

            ofstream f1("records.txt", ios::out | ios::app);

            f1 << ruser << " " << rpassword << endl;

            cout << "\t\t\nYour Registration has been done successfully\t\t\n";
            break;

                }
                default: {
                    cout << "\t\t\nInvalid input. Please enter a valid integer.\n";
                    break;
                }
            }
            break;
        }
        default: {
            cout << "\t\t\nInvalid input. Please enter a valid integer.\n";
            break;
        }
    }
}


void Admin::adisplaynotifications() {
    int c;
    char notifications[200];

    cout << "\t\t\t\nEnter the notification you want to be displayed :\t\t\n";
    cin.ignore();
    cin.getline(notifications, 200); // taka pori line read ho

    ofstream f1("notification.txt", ios::out | ios::app);
    f1 << notifications << endl; // Write the notification to the file

    cout << "\t\t\nYour notification has been displayed successfully\t\t\n";
}

void Admin::aseeonlineorder() {
   int c;

    char hdr1[100], hdr[100];
    char **person_name;                 //ye pt to pt ha aur hr pt aage se char arr ko pt kr rha ha
    char **item_name;
    char **delivery_time;
    int *item_quantity;

    int i = 0;

    fstream fs("onlineoreder.txt", ios::in);

    if (!fs) {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    } else {
        cout << "\nFile Found Congrats";
        fs.getline(hdr1, 100, '\n'); // reading first line of file
        fs.getline(hdr, 100, '\n');  // reading second line of file

        // Initialize dynamic arrays
        person_name = new char *[20];
        item_name = new char *[20];
        delivery_time = new char *[20];
        item_quantity = new int[20];

        for (int j = 0; j < 10; j++) {
            person_name[j] = new char[20];
            item_name[j] = new char[15];
            delivery_time[j] = new char[10];
        }

        // Reading remaining records of file in arrays appropriately
        while (fs >> person_name[i] >> item_name[i] >> item_quantity[i] >> delivery_time[i]) {
            fs.ignore(); // ignore the newline character
            i++;
        }
    }

    fs.close();

    // Now printing data from arrays on the screen
    cout << "\nData read from file in arrays ::: \n";
    cout << "\n" << hdr1 << endl;
    cout << "\n" << hdr << endl;
    for (int k = 0; k < i; k++) {
        cout << person_name[k] << "    |    " << item_name[k] << "    |    " << item_quantity[k] << "    |    "
             << delivery_time[k] << endl;
    }

    // Deallocate memory    //ap ne kha tha
    for (int j = 0; j < 10; j++) {
        delete[] person_name[j];
        delete[] item_name[j];
        delete[] delivery_time[j];
    }
    delete[] person_name;
    delete[] item_name;
    delete[] delivery_time;
    delete[] item_quantity;

}

void Admin::aseecomplaints() {
char hdr[20], complain[20][200];
    int c;

    int i = 0;

    ifstream fs("complains.txt"); // Open the file in input mode only

    if (!fs) {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    } else {
        cout << "\nFile Found Congrats";
        fs.getline(hdr, 20, '\n'); // Reading the header

        // Reading the remaining records of the file in arrays appropriately
        while (fs.getline(complain[i], 200, '\n')) {

            i++;
        }
    }

    fs.close();

    // Now printing data from arrays on the screen
    cout << "\n\t\tComplains read from the file:\n";
    cout << hdr << endl;

    for (int k = 0; k < i; k++) {
        cout << complain[k] << endl;
    }

}

void Admin::abestemployee() {
    int c, a;
    cout << "\t\t\nPress 1 to see best employee\n";
    cout << "\t\t\nPress 2 to exit\n";
    cin >> c;

    switch (c) {
        case 1: {
            cout << "==============================================\n";
            cout << "       OUR BEST EMPLOYEE IS BILAL       \n";
            cout << "==============================================\n\n";
            break;
        }
        case 2:
            cout << "\t\t\nBYE_BYE\t\t\n";
            break;

        default: {
            if (!(cin >> c)) {

                cout << "\t\t\nInvalid input. Please enter a valid integer.\n";
                cin.clear();
                cin.ignore();
                break;

            }
        }


    }
}

     void Admin::removePerson1() {
    char username[20];
    cout << "Enter the username to remove: ";
    cin >> username;

    ifstream fin("student.txt"); // Open the file for reading
    ofstream fout("tempo.txt"); // Open a temporary file for writing

    string line;
    bool found = false;

    // Read the file line by line
    while (getline(fin, line)) {
        // Check if the line contains the username
        if (line.find(username) != string::npos) {
            found = true; // Set found flag to true if username is found
            continue; // Skip writing this line to the temporary file
        }

        // Write the line to the temporary file
        fout << line << endl;
    }

    fin.close(); // Close the input file
    fout.close(); // Close the temporary file

    if (!found) {
        cout << "User not found in the records." << endl;
        remove("tempo.txt"); // Delete the temporary file
    } else {
        cout << "User '" << username << "' removed from the records." << endl;
        remove("student.txt"); // Delete the original file
        rename("tempo.txt", "student.txt"); // Rename the temporary file to original
    }
}
void Admin::removePerson() {
    char username[20];
    cout << "Enter the username to remove: ";
    cin >> username;

    ifstream fin("records.txt"); // Open the file for reading
    ofstream fout("temp.txt"); // Open a temporary file for writing

    string line;
    bool found = false;

    // Read the file line by line
    while (getline(fin, line)) {
        // Check if the line contains the username
        if (line.find(username) != string::npos) {
            found = true; // Set found flag to true if username is found
            continue; // Skip writing this line to the temporary file
        }

        // Write the line to the temporary file
        fout << line << endl;
    }

    fin.close(); // Close the input file
    fout.close(); // Close the temporary file

    if (!found) {
        cout << "User not found in the records." << endl;
        remove("temp.txt"); // Delete the temporary file
    } else {
        cout << "User '" << username << "' removed from the records." << endl;
        remove("records.txt"); // Delete the original file
        rename("temp.txt", "records.txt"); // Rename the temporary file to original
    }
}


