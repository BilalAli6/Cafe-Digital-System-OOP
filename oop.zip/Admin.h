#ifndef ADMIN_H
#define ADMIN_H

#include "User.h"

class Admin : public User {
public:

    virtual void login() override;
    virtual void registerUser() override;
    virtual void forgotPassword() override;
    void admin();
    void aseestock();
    void aseeloweritem();
    void aseelowerorderitem();
    void asearchitem();
    void aaddemployee();
    void adisplaynotifications();
    void aseeonlineorder();
    void aseecomplaints();
    void abestemployee();
    void removePerson();
    void removePerson1();
};

#endif // ADMIN_H

