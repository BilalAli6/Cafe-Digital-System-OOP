#ifndef STUDENT_H
#define STUDENT_H

#include "User.h"

class Student : public User {
public:
    virtual void login() override;
    virtual void registerUser() override;
    virtual void forgotPassword() override;
    void student();
    void sorderfood();
    void scomplaints();
    void ssearchitems();
    void sgasorder();
    void snotification();
};

#endif // STUDENT_H

