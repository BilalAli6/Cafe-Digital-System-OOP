#include <iostream>
#include <fstream>
#include <cstring>
#include <ctime>
#include <limits>
#include "Admin.h"
#include "Admin.cpp"
#include "Employee.h"
#include "Employee.cpp"
#include "Student.h"
#include "Student.cpp"

#define GREEN "\033[1;32m"
#define RESET "\033[0m"
#define RED   "\033[1;31m"
#define MAGNTA "\033[1;35m"

using namespace std;

int main() {
    char userType;
    cout<<MAGNTA;
    cout << "\n\n\t************************************************************\n";
    cout << "\t**********  WELCOME TO CAFE DIGITAL MANAGEMENT SYSTEM  *****\n";
    cout << "\t************************************************************\n\n";
    cout << "\t*************************************************************\n";
    cout << "\t*********** Explore our menu and enjoy your time! ***********\n";
    cout << "\t*************************************************************\n";
    cout<<RESET;

    while (true) {
        cout<<RED;
        cout<<"________________________________________________________________________________\n\n\n";
        cout<< "\t\t\t\tSelect user type:\n"
            <<"________________________________________________________________________________\n\n\n";
        cout<<RESET;

        cout << "\t\t\t\t1. Admin\n";
        cout << "\t\t\t\t2. Employee\n";
        cout << "\t\t\t\t3. Student\n";
        cout << "\t\t\t\t4. Exit\n";
        cout << "\nEnter your choice: ";
        cin >> userType;

        switch (userType) {
            case '1': {
                char adminChoice;
                Admin admin;

                cout << "\n\n\nChoose an option:\n";
                cout << "\t\t\t\t1. Login\n";
                cout << "\t\t\t\t2. Register\n";
                cout << "\t\t\t\t3. Forgot Password\n";
                cout << "\t\t\t\tEnter your choice: ";
                cin >> adminChoice;

                switch (adminChoice) {
                    case '1':
                        admin.login();  // Perform admin login
                        break;
                    case '2':
                        admin.registerUser();  // Register new admin
                        break;
                    case '3':
                        admin.forgotPassword();  // Recover forgotten password
                        break;
                    default:
                        cout << "Invalid choice. Please try again.\n";
                        continue;
                }

                while (true) {
                    cout<<GREEN;
                    admin.admin();
                    cout << "\t\t\nAdmin Menu:\n\n"
                        << "1. See Stock\n"
                        << "2. See Lower Item\n"
                        << "3. See Lower Order Item\n"
                        << "4. Search Item\n"
                        << "5. Add Employee\n"
                        << "6. Display Notifications\n"
                        << "7. See Online Orders\n"
                        << "8. See Complaints\n"
                        << "9. Best Employee\n"
                        << "0. Logout\n"
                        << "Enter your choice: ";
                    cout<<RESET;    

                    cin >> adminChoice;
                    switch (adminChoice) {
                        case '1':
                            admin.aseestock();
                            break;
                        case '2':
                            admin.aseeloweritem();
                            break;
                        case '3':
                            admin.aseelowerorderitem();
                            break;
                        case '4':
                            admin.asearchitem();
                            break;
                        case '5':
                            admin.aaddemployee();
                            break;
                        case '6':
                            admin.adisplaynotifications();
                            break;
                        case '7':
                            admin.aseeonlineorder();
                            break;
                        case '8':
                            admin.aseecomplaints();
                            break;
                        case '9':
                            admin.abestemployee();
                            break;
                        case '0':
                            cout << "Logging out...\n";
                            return 0;
                        default:
                            cout << "Invalid choice. Please try again.\n";
                            continue;
                    }
                }
            }
            case '2': {
                char empChoice;
                Employee emp;

                cout << "\n\n\nChoose an option:\n";
                cout << "\t\t\t\t1. Login\n";
                cout << "\t\t\t\t2. Register\n";
                cout << "\t\t\t\t3. Forgot Password\n";
                cout << "\t\t\t\tEnter your choice: ";
                cin >> empChoice;

                switch (empChoice) {
                    case '1':
                        emp.login();  // Perform employee login
                        break;
                    case '2':
                        emp.registerUser();  // Register new employee
                        break;
                    case '3':
                        emp.forgotPassword();  // Recover forgotten password
                        break;
                    default:
                        cout << "Invalid choice. Please try again.\n";
                        continue;
                }

                while (true) {
                    cout<<GREEN;
                    emp.employee();
                    cout << "\t\t\nEmployee Menu:\n\n"
                        << "1. Take Order\n"
                        << "2. Search Item\n"
                        << "3. Generate Transaction\n"
                        << "4. See Online Orders\n"
                        << "0. Logout\n"
                        << "Enter your choice: ";
                    cout<<RESET;    

                    cin >> empChoice;
                    switch (empChoice) {
                        case '1':
                            emp.etakeorder();
                            break;
                        case '2':
                            emp.esearchitem();
                            break;
                        case '3':
                            emp.egeneratetransaction();
                            break;
                        case '4':
                            emp.eseeonlineorder();
                            break;
                        case '0':
                            cout << "Logging out...\n";
                            return 0;
                        default:
                            cout << "Invalid choice. Please try again.\n";
                            continue;
                    }
                }
            }
            case '3': {
                char stuChoice;
                Student stu;

                cout << "\n\n\nChoose an option:\n";
                cout << "\t\t\t\t1. Login\n";
                cout << "\t\t\t\t2. Register\n";
                cout << "\t\t\t\t3. Forgot Password\n";
                cout << "\t\t\t\tEnter your choice: ";
                cin >> stuChoice;

                switch (stuChoice) {
                    case '1':
                        stu.login();  // Perform student login
                        break;
                    case '2':
                        stu.registerUser();  // Register new student
                        break;
                    case '3':
                        stu.forgotPassword();  // Recover forgotten password
                        break;
                    default:
                        cout << "Invalid choice. Please try again.\n";
                        continue;
                }

                while (true) {
                    cout<<GREEN;
                    stu.student();
                    cout << "\t\t\nStudent Menu:\n\n"
                        << "1. Order Food\n"
                        << "2. Register Complaint\n"
                        << "3. Search Items\n"
                        << "4. Give Gas Order\n"
                        << "5. Notification\n"
                        << "0. Logout\n"
                        << "Enter your choice: ";
                    cout<<RESET;    

                    cin >> stuChoice;
                    switch (stuChoice) {
                        case '1':
                            stu.sorderfood();
                            break;
                        case '2':
                            stu.scomplaints();
                            break;
                        case '3':
                            stu.ssearchitems();
                            break;
                        case '4':
                            stu.sgasorder();
                            break;
                        case '5':
                            stu.snotification();
                            break;
                        case '0':
                            cout << "Logging out...\n";
                            return 0;
                        default:
                            cout << "Invalid choice. Please try again.\n";
                            continue;
                    }
                }
            }
            case '4':
                cout << "Exiting...\n";
                return 0;
            default:
                cout << "Invalid choice. Please try again.\n";
                continue;
        }
    }

    return 0;
}

