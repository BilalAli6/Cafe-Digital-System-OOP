#include "Student.h"
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

// Implementing member functions of Student class
void Student::login() {
ifstream fs("student.txt", ios::in);
    if (!fs) {
        cout << "\nFile Not Found\n\nCheck File Name";
    } else {
        int role;
        cout << "\nFile Foundd\n";

        char password[20];
        char id[20];
        char user[20];
        char pass[20];
        int count = 0;

        cout << "\t\t\nPlease Enter UserName and Pin :\n";
        cout << "\t\tUserName\n";
        cin >> user;
        cout << "\t\t\nPin\n";
        cin >> password;

        ifstream input("student.txt");
        while (input >> id >> pass) {
            if (strcmp(id, user) == 0 && strcmp(pass, password) == 0) {
                count = 1;
            }
        }
        input.close();

        if (count == 1) {
            cout << user << "\n\tYou are logged in successfully\n\t";
        } else {
            cout << "\t\t\nLogin Error\nPlease Try Again\n\t";
            login(); // Recursively call login if login fails
        }
    }
}

void Student::registerUser() {
 char ruser[20];
    char rpassword[20];

    cout << "\t\t\t\nEnter the user name :\t\t\n";
    cin >> ruser;

    cout << "\t\t\t\nEnter the Pin :\t\t\n";
    cin >> rpassword;

    ofstream f1("student.txt", ios::out | ios::app);

    f1 << ruser << " " << rpassword << endl;

    cout << "\t\t\nYour Registration has been done successfully\t\t\n";
}

void Student::forgotPassword() {
 int option;
    cout << "\t\t\t\nYou forgot the password.\nNo worries:)\t\t\n";
    cout << "\nPress 1 to search your id by user name :\n";
    cout << "\nPress 2 to go back to the main menu :\n\n";
    cout << "\t\tEnter your choice :\t\t";
    cin >> option;

    switch (option) {
        case 1: {
            int count = 0;

            char suser[20];
            char sid[20];
            char spass[20];

            cout << "\t\t\nEnter username which you remember :\t\t\n";
            cin >> suser;

            ifstream f2("student.txt");

            while (f2 >> sid >> spass) {
                if (strcmp(sid, suser) == 0) {
                    count = 1;
                    break;
                }
            }

            f2.close();

            if (count == 1) {
                cout << "\t\t\nCongrats Your account has been found\t\t\n";
                cout << "\t\t\nYour Pin is :" << spass << endl;
            } else {
                cout << "\t\t\nYour account has not been found\t\t\n";
            }
            break;
        }
        case 2: {
            // Return to main menu
            break;
        }
        default: {
            cout << "\t\t\nWrong Choice Please Try Again\t\t\n";
            forgotPassword(); // Recursively call forgotPassword if choice is invalid
            break;
        }
    }
}

void Student::student() {
    cout << "\n\t\t\t\t==============================================\n";
    cout << "\t\t\t\t       WELCOME TO THE STUDENT CDS SYSTEM       \n";
    cout << "\t\t\t\t==============================================\n\n";
}

void Student::sorderfood() {
char hdr[50], Name[5][10], search[20], userResponse, user[20];
    double Price[5];
    int No_Items[5];
    int i = 0, p = 0;

    fstream fs("stock.txt", ios::in);

    if (!fs) {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    } else {
        cout << "\nFile Found Congrats";
        fs.getline(hdr, 50, '\n'); //reading first line of file
        //reading remaining records of file in arrays appropriately
        while (fs.getline(Name[i], 10, ' '), fs >> Price[i] >> No_Items[i]) {
            fs.ignore();
            i++;
        }
    }

    fs.close();
    //now printing data from arrays on screen

    cout << "\nData read from file in arrays ::: \n";
    cout << "\n" << hdr << endl;
    for (int k = 0; k < i; k++) {
        cout << Name[k] << "    |    " << Price[k] << "    |    " << No_Items[k] << endl;
    }

    do {
        cout << "\nEnter the item name you want to order (or type 'end' to exit): ";
        cin.ignore();   // Ignore any previous newline characters
        cin.getline(search, sizeof(search));       //size is liye taka agar bnda bara bhi value dale wo read kr le

        if (strcmp(search, "end") == 0) {
            cout << "\n\t\tGood Bye Have a nice day\n\n";
            break;
        }

        int p = 0;
        while (p < i && strcmp(Name[p], search) != 0) {
            p++;
        }

        if (p < i) {
            cout << "\nEnter the quantity you want to order for " << search << ": ";
            int quantity;
            cin >> quantity;

            if (No_Items[p] >= quantity) {
                // Sufficient quantity is available
                double totalBill = Price[p] * quantity;

                // Display the bill
                cout << "\n\nYour Bill:\n";
                cout << "Item: " << Name[p] << "\n";
                cout << "Price per item: " << Price[p] << "\n";
                cout << "Quantity: " << quantity << "\n";
                cout << "Total Bill: " << totalBill << "\n";

                cout << "Do you have enough money to pay the bill? (Y/N): ";
                cin >> userResponse;

                if (userResponse == 'Y' || userResponse == 'y') {
                    cout << "Thank you for your order. Payment successful!\n";

                    // Update the quantity in the array
                    No_Items[p] -= quantity;

                    // Now, update the stock.txt file with the new quantity 
                    ofstream updateFile("stock.txt");
                    updateFile << hdr << endl;

                    for (int k = 0; k < i; k++) {
                        updateFile << Name[k] << " " << Price[k] << " " << No_Items[k] << endl;
                    }

                    updateFile.close();

                    fstream fs("etrans.txt", ios::app);
                    fs << "MR." << user << "'s order\n";
                    fs << "Item : " << Name[p] << "\n";
                    fs << "Ordered Quantity : " << quantity << "\n";
                    fs << "Remaining Quantity in Stock : " << No_Items[p] << "\n";
                    fs << "Total Price of order : " << totalBill << "\n";
                    fs << "------------------------------------\n";
                    fs.close();
                } else {
                    cout << "Sorry, you don't have enough money to pay the bill. Please come back when you're ready to pay.\n";
                    break;
                }
            } else {
                // Insufficient quantity
                cout << "\n\nSorry, there is insufficient quantity for " << search << ".\n";

                fstream fs("loworders.txt", ios::app);
                fs << "Item: " << Name[p] << "\n";
                fs << "Ordered Quantity: " << quantity << "\n";
                fs << "Remaining Quantity in Stock: " << No_Items[p] << "\n";
                fs << "------------------------------------\n";
                fs.close();
            }
        } else {
            // Item not found
            cout << "\n\nSorry, the item " << search << " is not found.\n";
            break;
        }
    } while (true);

}

void Student::scomplaints() {
    int c;
    char complains[200];

    cout << "\t\t\t\nEnter the complain you want to send to admin :\t\t\n";
    cin.ignore();
    cin.getline(complains, 200); // taka pori line read ho

    ofstream f1("complains.txt", ios::out | ios::app);
    f1 << complains << endl; // Write the complain to the file

    cout << "\t\t\nYour complain has been sent to admin successfully\t\t\n";
}

void Student::ssearchitems() {
    int c;
    char hdr[50], Name[5][20];
    double Price[5];
    int No_Items[5];
    int i = 0;

    fstream fs("stock.txt", ios::in);

    if (!fs) //check if file is not available to read
    {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    } else //file is available for reading now loading data in arrays appropriately
    {
        cout << "\nFile Found Congrats";
        fs.getline(hdr, 50, '\n'); //reading first line of file
        //reading remaining records of file in arrays appropriately
        while (fs.getline(Name[i], 20, ' '), fs >> Price[i] >> No_Items[i]) {
            fs.ignore();
            i++;
        }
    }

    fs.close();
    //now printing data from arrays on screen

    cout << "\nData read from file in arrays ::: \n";
    cout << "\n" << hdr << endl;
    for (int k = 0; k < i; k++) {
        cout << Name[k] << "    |    " << Price[k] << "    |    " << No_Items[k] << endl;
    }

    char search[] = "Chowmin"; ///you can take input here as well
    int p = 0;

    while (1) //this loop is used to find location in array.
    {
        if (strcmp(Name[p], search) == 0) {
            break;
        } else
            p++;
    }
    cout << "\n\nFound at location = " << p << "\n\n";
}


void Student::sgasorder() {
    char item_name[15], person_name[20], delivery_time[10];
    int item_quantity, c;

    fstream fo;

    fo.open("onlineoreder.txt", ios::out | ios::app);

    cout << "==============================================\n";
    cout << "       WELCOME TO THE ONLINE CDS SYSTEM       \n";
    cout << "==============================================\n\n";
    cout << "Order Whatever you want we'll bring for you whether it is in our menu or not";

    cout << "\n\t\tEnter your name : ";
    cin >> person_name;
    cin.ignore();

    cout << "\n\t\tEnter the item you want to order : ";
    cin >> item_name;
    cin.ignore();

    cout << "\n\t\tEnter the quantity of your item you want to order : ";
    cin >> item_quantity;
    cin.ignore();

    cout << "\n\t\tEnter the time you want to deliver your food : ";
    cin >> delivery_time;
    cin.ignore();

    fo << person_name << " " << item_name << " " << item_quantity << " " << delivery_time << endl;

    fo.close();
}

void Student::snotification() {
int c;
    char hdr[20], notifications[4][200];

    int i = 0;

    ifstream fs("notification.txt"); // Open the file in input mode only

    if (!fs) {
        cout << "\nFile not found";
        cout << "\nCheck file name";
    } else {
        cout << "\nFile Found Congrats";
        fs.getline(hdr, 20, '\n'); // Reading the header

        // Reading the remaining records of the file in arrays appropriately
        while (fs.getline(notifications[i], 200, '\n')) {

            i++;
        }
    }

    fs.close();

    // Now printing data from arrays on the screen
    cout << "\nNotifications read from the file:\n";
    cout << hdr << endl;

    for (int k = 0; k < i; k++) {
        cout << notifications[k] << endl;
    }
}

